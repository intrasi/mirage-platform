Install Python 3.12 dependencies from requirements.lock.
Run: python run.py 812 300 -21
Expected output: 931
This package includes a native extension for the platform in manifest.json.
It does not require PyTorch or NumPy.
Send repeated input lines to keep the virtual machine active.
The model regenerates inactive regions and renews decoding material after 256 calls.
Physical edge deployment is not verified.
